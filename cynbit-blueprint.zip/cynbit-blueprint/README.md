# Cynbit Blueprint: website improvements prototype

A working prototype of three improvements to [cynbit.in](https://www.cynbit.in), built for the *Full Stack Developer Intern: Improve Cynbit's Website* assessment.

> **Live demo:** `https://<your-deployment>.vercel.app` · **Team dashboard:** `/admin` (demo password `cynbit-demo`)

| | Improvement | Problem it solves on cynbit.in |
|---|---|---|
| 1 | **AI Project Blueprint** (`/start`) | Every CTA ends at one generic form with a blank message box. There's no price or timeline until someone replies, and booking a call takes emails back and forth. |
| 2 | **Ask Cynbit assistant** (chat button on every page) | An AI-automation company with no AI on its own site. Visitors have to dig through pages to find fees, services or contact details. |
| 3 | **BitElevate Path Finder** (`/bitelevate`) | "Generate My Custom Path" doesn't explain how a lab is chosen, and there's no way to track an application. |
| + | **Team dashboard** (`/admin`) | Leads arrive as unstructured text and have to be qualified by hand. |

![Blueprint flow](docs/screenshots/03-start-features.png)

---

## What it does

### 1. AI Project Blueprint
- A five-step guided flow: **service → features → goal → timeline & budget → contact**. Unfinished answers are saved in the browser.
- **Live estimate:** the cost range, timeline, team size and a phase plan update as the visitor picks options. They're calculated by a pure, deterministic estimator (`src/lib/estimate.ts`) driven by one config file (`src/lib/pricing.config.ts`).
- **AI project brief:** the server sends the structured answers to an LLM, which returns a JSON brief (summary, objectives, scope, risks, questions for the call, suggested stack). The prompt tells the model never to change the estimate.
- **Self-serve booking:** 30-minute IST slots (Mon–Sat, 11:00–18:00). Double-booking is blocked by a database `UNIQUE` constraint. The visitor gets a `.ics` calendar invite.
- **Shareable blueprint page** (`/start/<id>`) with an unguessable ID, and print/PDF support.

### 2. Ask Cynbit
- **Retrieval-augmented answers** from a knowledge base written from Cynbit's own pages (`src/lib/kb/cynbit.ts`). The model is told to answer only from the context and to say when it doesn't know.
- **BM25 retrieval with query coverage.** A page has to cover most of the visitor's important words, so a question like "Do you sign NDAs before a call?" isn't matched to a page just because both mention "call".
- **Source chips** link to the cynbit.in pages, and **next-step buttons** offer the estimate, the lab finder or email, depending on the question.
- **Every unanswered question is logged** and shown on the dashboard as a content gap.

### 3. BitElevate Path Finder
- Three questions score all six BitElevate labs and show the match, the reasons ("you picked …"), the stack and the roles it leads to.
- One-step application → a code like `BE-7K3QX9` → a status page (`/bitelevate/status`) with a timeline: Submitted → Under review → Advisor call → Enrolled (or Waitlisted). The team can attach a note.
- A lookup needs both the code and the email, and both kinds of mismatch return the same error, so codes can't be enumerated.

### Team dashboard
- KPIs: leads, hot leads, open pipeline value, booked calls, applications, and the share of assistant questions answered.
- Leads are sorted by a **transparent score (0–100)** with a readable breakdown (e.g. `+30 budget covers the estimate, +15 founder…`), plus the AI brief and a status pipeline (new → contacted → proposal → won/lost).
- Application review with status changes and notes, a list of unanswered assistant questions, and CSV export (protected against formula injection).

---

## Architecture

```
Browser (React 19, Tailwind 4)
  │  /start wizard ── live estimate runs client-side (same pure function as the server)
  │  Chat widget, Path Finder, Status lookup, Admin
  ▼
Next.js 15 App Router (route handlers, Node runtime)
  ├─ /api/blueprint        validate (zod) → estimate → AI brief → score → store
  ├─ /api/slots, /book, /ics
  ├─ /api/chat             retrieve (BM25) → LLM (grounded) → log
  ├─ /api/bitelevate/*     apply, status
  ├─ /api/admin/*          login, status updates, CSV export   ← middleware-protected
  └─ /api/health           storage + AI provider in use
        │                         │
        ▼                         ▼
   Store interface          AI client (fetch, no SDKs)
   ├─ PostgresStore         ├─ Gemini  (default when GEMINI_API_KEY is set)
   └─ MemoryStore (demo)    ├─ OpenAI
                            ├─ Anthropic Claude
                            └─ none → deterministic fallback
```

**Graceful degradation is a core design rule.** With no API key, an expired key, a rate limit, a timeout or malformed model output, the site keeps working. The brief falls back to a rule-based generator, and the assistant answers from the best-matching page or honestly says it doesn't know.

## Tech choices

| Choice | Why |
|---|---|
| **Next.js 15 (App Router) + TypeScript** | Matches what Cynbit already uses (Next.js meta tags on cynbit.in; Next.js 15 in the BitElevate Full Stack lab). One codebase for UI and API, and it deploys to Vercel with no config. |
| **Tailwind CSS 4** | Fast to build a consistent dark UI with no runtime CSS. |
| **zod** | One schema validates every API body and produces readable errors. |
| **Postgres via `postgres` (postgres.js)** | Small, fast, no codegen or binary engine. Tables are created automatically on first use. JSONB keeps the lead/brief shape flexible, while the columns that matter (status, score, booked slot) stay indexed and constrained. |
| **Pluggable LLM client over `fetch`** | No vendor lock-in. Switching provider is one env var, and the bundle carries no SDK weight. |
| **BM25 instead of embeddings** | With about 20 short pages, BM25 is accurate, instant and free, and needs no second API or vector DB. The `retrieve()` interface means embeddings can replace it later without touching callers. |
| **Rule-based lead score** | The sales team can read exactly why a lead scored as it did. An LLM score would be a black box and could vary between runs. |

## Run locally

```bash
npm install
cp .env.example .env.local   # optional — everything works with no keys
npm run dev                  # http://localhost:3000
npm test                     # 25 tests: estimator, scoring, retrieval, slots, auth, AI providers (stubbed), Postgres store (in-process PGlite)
npm run build
```

With no `DATABASE_URL`, the app uses an in-memory store seeded with clearly labelled demo data.

### Environment variables

| Variable | Purpose |
|---|---|
| `AI_PROVIDER` | `gemini` \| `openai` \| `anthropic` \| `none`. Leave empty to auto-detect from whichever key is set. |
| `GEMINI_API_KEY` / `OPENAI_API_KEY` / `ANTHROPIC_API_KEY` | Provider keys. Gemini has a free tier ([aistudio.google.com/apikey](https://aistudio.google.com/apikey)). |
| `AI_MODEL` | Optional model override. Defaults: `gemini-2.5-flash`, `gpt-4.1-mini`, `claude-haiku-5-5`. |
| `DATABASE_URL` (or `POSTGRES_URL`) | Postgres connection string (Neon, Supabase, Vercel Postgres). |
| `ADMIN_PASSWORD` | Dashboard password. Falls back to `cynbit-demo`, and the login page then says so. |
| `SESSION_SECRET` | Long random string used to sign the admin cookie. |

## Deploy (Vercel + Neon, both free)

1. Push this repo to GitHub, then on vercel.com choose **Add New → Project → Import** this repo.
2. In the project, go to **Storage → Create → Neon (Postgres)** and connect it. This sets `DATABASE_URL`/`POSTGRES_URL` automatically.
3. Under **Settings → Environment Variables**, add `GEMINI_API_KEY` (or another provider key), `ADMIN_PASSWORD` and `SESSION_SECRET`.
4. Redeploy. Check `/api/health`: it should show `"storage":"postgres"` and your AI provider.

> On serverless hosts, set a database. The in-memory store lives inside a single function instance, so a blueprint created by one instance might not be visible to another. Memory mode is meant for local development and quick demos.

## Security and abuse controls
- zod validation on every endpoint; honeypot fields on public forms.
- Per-IP rate limits on the AI, booking, application, status and login endpoints.
- HMAC-signed, expiring, `httpOnly` admin cookie, checked in middleware for `/admin` and `/api/admin/*`. Password comparison doesn't leak timing.
- Unguessable blueprint IDs. Status lookups need code + email. Security headers (`X-Frame-Options`, `nosniff`, `Referrer-Policy`, `Permissions-Policy`). `noindex` on the prototype.

## Project structure

```
src/
  app/
    page.tsx                 landing page + before/after
    start/                   Blueprint wizard, result page, booking
    bitelevate/              Path Finder, application, status tracker
    admin/                   login + dashboard
    api/                     route handlers (see Architecture)
  components/                header, footer, chat widget
  lib/
    pricing.config.ts        ← the only file Cynbit needs to edit to match its real rate card
    estimate.ts scoring.ts brief.ts assistant.ts retrieval.ts pathfinder.ts slots.ts auth.ts
    ai/                      provider-agnostic LLM client
    kb/cynbit.ts             assistant knowledge base
    store/                   Store interface, Postgres + in-memory implementations, demo seed
tests/                       node:test unit tests
```

## Honest limitations
- **Prices are assumptions.** Cynbit publishes no rates, so `pricing.config.ts` uses typical Indian agency figures. Every page labels the range as indicative.
- **No outbound email yet.** Bookings and applications appear on the dashboard right away. Sending confirmations needs an email provider (e.g. Resend) and is the next step.
- **The knowledge base is hand-written** from the public pages (Nov 2026). In production, a build-time crawler of cynbit.in would regenerate it.
- **This is a standalone prototype, not a patch to cynbit.in**, because the site's source isn't public. Every piece is a self-contained component plus an API route, so it can be moved into Cynbit's Next.js codebase.

## Next steps
1. Email + WhatsApp confirmations (Resend / WhatsApp Business API) and Google Calendar sync for bookings.
2. Crawl cynbit.in at build time to keep the assistant's knowledge base current.
3. Analytics events (`blueprint_started`, `step_completed`, `call_booked`) to measure funnel drop-off and A/B test against the old contact form.
4. Hand off hot leads to a CRM (HubSpot/Zoho) through a webhook.
