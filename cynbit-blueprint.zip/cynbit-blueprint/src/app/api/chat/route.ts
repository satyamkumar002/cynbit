import { NextResponse } from "next/server";
import { z } from "zod";
import { answer } from "@/lib/assistant";
import { clientIp, jsonError, rateLimit } from "@/lib/http";
import { chatId } from "@/lib/ids";
import { getStore } from "@/lib/store";

export const runtime = "nodejs";

const schema = z.object({
  message: z.string().trim().min(1).max(500),
  history: z
    .array(z.object({ role: z.enum(["user", "assistant"]), content: z.string().max(2000) }))
    .max(12)
    .default([]),
});

export async function POST(req: Request) {
  if (!rateLimit(`chat:${clientIp(req)}`, 20, 5 * 60_000)) {
    return jsonError("You're sending messages quickly — please wait a minute.", 429);
  }
  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return jsonError("Please type a question (max 500 characters).", 422);

  const { message, history } = parsed.data;
  const reply = await answer(message, history);

  // Unanswered questions show up in the admin dashboard as content gaps.
  await getStore()
    .logChat({
      id: chatId(),
      createdAt: new Date().toISOString(),
      question: message,
      answered: reply.answered,
      source: reply.source,
      topSources: reply.sources.map((s) => s.title),
    })
    .catch((e) => console.error("[chat] log failed", e));

  return NextResponse.json(reply);
}
